// Nooshad UI helpers
(function(){
  function toggle(cls){ document.body.classList.toggle(cls); }
  document.addEventListener('click', function(e){
    const b=e.target.closest('.app-body .hamb');
    if(b){ e.preventDefault(); toggle('nav-open'); return; }
    const site=e.target.closest('.site-body .hamb');
    if(site){ e.preventDefault(); toggle('menu-open'); return; }
  });
  document.addEventListener('click', function(e){
    const link=e.target.closest('.sidebar a');
    if(link && window.innerWidth<=900) document.body.classList.remove('nav-open');
  });
  document.querySelectorAll('form').forEach(function(f){
    f.addEventListener('submit',function(){
      const b=f.querySelector('button[type=submit],button:not([type])');
      if(b){b.disabled=true;b.dataset.old=b.textContent;b.textContent='در حال پردازش…';}
    });
  });
})();
